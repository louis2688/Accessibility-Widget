# Accessibility-Widget
Accessibility Widget for the web audit 
